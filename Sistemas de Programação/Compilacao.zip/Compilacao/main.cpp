#include "foo.h"

int main(){
	A(10);
	return 0;
}