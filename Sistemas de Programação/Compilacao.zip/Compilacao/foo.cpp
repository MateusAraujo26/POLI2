#include "foo.h"
#include <iostream>

int A(int b) {
    std::cout << b;
    return b * b;
}
