#ifndef FOO_H
#define FOO_H

int A(int b);

#endif // FOO_H
